import { HasaccessDirective } from './hasaccess.directive';

describe('HasaccessDirective', () => {
  it('should create an instance', () => {
    const directive = new HasaccessDirective();
    expect(directive).toBeTruthy();
  });
});
