export class User {
  id: any;
  username = '';
  password = '';
  fullName = '';
  phone: any;
  firstName: any;
  lastName: any;
  code: any;
}
