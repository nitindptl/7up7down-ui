import { Component, OnInit } from '@angular/core';
import { User } from '../model/model.user';
import { AccountService } from '../account/account.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  users: any = [];
  constructor(private accountService:AccountService) { }

  ngOnInit() {
    this.getUsersList();
  }

  getUsersList() {
    this.accountService.getAllAccounts().subscribe(response =>{
      this.users = response;
    }); 
  }
}
