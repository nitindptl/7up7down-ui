import { Component, OnInit } from '@angular/core';
import { ContestService } from '../contest/contest.service';
import { AppComponent } from '../app.component';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-challenge',
  templateUrl: './challenge.component.html',
  styleUrls: ['./challenge.component.css']
})
export class ChallengeComponent implements OnInit {

  constructor(private contestService: ContestService) { }
  challenge: any = {};
  challengeReq: any = {};
  challengeList: any = []
  createNew = true;
  contest: any;
  result: any = {
    card: { value: null, symbol: '', color: '' }
  };
  rule1: any = [];
  rule2: any = [];
  rule3: any = [];
  obs: any = {};

  activeChallenges: any = [];
  ngOnInit() {
    this.getActiveContest();
    this.getAllRules();
    this.obs = setInterval(() => {
      if (this.contest) {
        this.getResult();
        this.getUserChallenges();
      }
    }, 15000);
  }


  getResult() {
    this.contestService.getContestResult(this.contest.id).subscribe(response => {
      //this.result = response;
      if (response.card!==null) {
        this.result.card.value = response.card.split('_')[0];
        this.result.card.symbol = response.card.split('_')[2];
        this.result.card.color = response.card.split('_')[1];
      }
    });
  }

  isChallengeCategory(cat: number) {
    var chang = [];
    if(this.activeChallenges)
      chang = this.activeChallenges.filter(ch => ch.rule.type == cat);
    
    if (chang.length!=0) {
      if (cat == 1) {
        this.rule1['selected'] = chang[0].name;
      } else if (cat == 2){
        this.rule2['selected'] = chang[0].name;
      } else {
        this.rule3['selected'] = chang[0].name;
      }
    }
    return chang.length == 0 ? false : true;
  }
  getAllRules() {
    this.contestService.getAllRules().subscribe(response => {
      this.rule1 = response["Rule1"];
      this.rule2 = response["Rule2"];
      this.rule3 = response["Rule3"];
    });
  }
  selectRule(cat: number, id: any) {
    let rule = {};

    if (cat == 1) {
      rule = this.rule1.filter((r) => r.id == id);
    } else if (cat == 2){
      rule = this.rule2.filter((r) => r.id == id);
    } else {
      rule = this.rule3.filter((r) => r.id == id);
    }
    this.challengeReq.user = AppComponent.USER;
    this.challengeReq.rule = rule[0];
  }
  getActiveContest() {
    this.contestService.getActiveContest().subscribe(response => {
      this.contest = response;
      this.getUserChallenges();
    });
  }

  getUserChallenges() {
    if (!this.contest)
      return;
    this.contestService.getUserChallenges(this.contest.id).subscribe(response => {
      this.activeChallenges = response;
      
    });
  }
  joinChallenge(amount: number) {
    this.challengeReq.amount = amount;
    this.contestService.participateInContest(this.challengeReq).subscribe(response => {
      this.challenge = {};
      this.getUserChallenges();
    });
  }
  ngOnDestroy() {
    if (this.obs) {
      clearInterval(this.obs);
    }
  }
}
