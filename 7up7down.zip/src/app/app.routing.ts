import { Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from './components/login/login.component';
import {RegisterComponent} from './components/register/register.component';
import {UrlPermission} from './urlPermission/url.permissions';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { HomeComponent } from './components/layout/home.component';
import { ContestComponent } from './contest/contest.component';
import { UserComponent } from './user/user.component';
import { AccountComponent } from './account/account.component';
import { ChallengeComponent } from './challenge/challenge.component';


const appRoutes: Routes = [
  {
    path: 'app', component: HomeComponent, canActivate: [UrlPermission],
    children: [
      { path: 'contest', component: ContestComponent, canActivate: [UrlPermission] },
      { path: 'user', component: UserComponent, canActivate: [UrlPermission] },
      { path: 'account', component: AccountComponent, canActivate: [UrlPermission] },
      { path: 'join-contest', component: ChallengeComponent, canActivate: [UrlPermission] }
    ]
  },
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'not-found', component: NotFoundComponent },
  // otherwise redirect to profile
  { path: '**', redirectTo: '/not-found' }
];

export const routing = RouterModule.forRoot(appRoutes);
