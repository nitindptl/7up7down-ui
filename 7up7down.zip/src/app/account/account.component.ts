import { Component, OnInit } from '@angular/core';
import { AccountService } from './account.service';
import { User } from '../model/model.user';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {

  user: User = new User();
  account: any = {};
  transactions: any = [];
  constructor(private accountService:AccountService) { }
 
  ngOnInit() {
    this.getAccountDetails();
    this.getAccountTransactions();
  }

  isAdmin() {
    return AppComponent.ROLES.indexOf("ROLE_ADMIN")==-1?false:true;
  }
  getAccountDetails() {
    this.accountService.getAccount(AppComponent.USER).subscribe((response) =>{
      this.account = response;
    }); 
  }
  getAccountTransactions() {
    this.accountService.getAccountTransaction(AppComponent.USER).subscribe((response) =>{
      this.transactions = response;
    }); 
  }

  addPoints(action:string) {
    this.accountService.addPoints(this.account.phone,this.account.points,action).subscribe((response) =>{
      this.account = response;
      this.getAccountDetails();
    }); 
  }
}
