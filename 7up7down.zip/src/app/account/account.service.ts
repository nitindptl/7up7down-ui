import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {User} from '../model/model.user';
import {Http} from '@angular/http';
import {AppComponent} from '../app.component';

@Injectable()
export class AccountService {
  constructor(public http: HttpClient) { }

  getAccount(user: User) {
    return this.http.get(AppComponent.API_URL + '/account/'+ user.id);
  }
  getAllAccounts() {
    return this.http.get(AppComponent.API_URL + '/account/all');
  }
  getAccountTransaction(user: User) {
    return this.http.get(AppComponent.API_URL + '/account/' + user.id + '/transaction');
  }
  registerUser(code:number,user: User) {
    return this.http.post(AppComponent.API_URL + '/signup/'+code, user);
  }

  logOut() {
    // remove user from local storage to log user out
    return this.http.post(AppComponent.API_URL + '/auth/logout', {});

  }
  addPoints(userId:number,points:number,action:string) {
    // remove user from local storage to log user out
    return this.http.put(AppComponent.API_URL + '/account/'+userId+'/points/'+action+'/'+points,{});

  }
}
