import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../../account/account.service';
import { Router } from '@angular/router';
import { AppComponent } from '../../../app.component';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  constructor(private accountService:AccountService,private router: Router) { }

  ngOnInit() {
  }

  isAdmin() {
    return AppComponent.ROLES.indexOf("ROLE_ADMIN")==-1?false:true;
  }
  logout() {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('token');
    localStorage.removeItem('roles');
    this.router.navigateByUrl('/login');
    this.accountService.logOut().subscribe((response) => {
      localStorage.removeItem('currentUser');
      localStorage.removeItem('token');
    }); 
  }
}
