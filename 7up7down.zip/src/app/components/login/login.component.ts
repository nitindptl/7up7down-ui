import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { User } from '../../model/model.user';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { AppComponent } from '../../app.component';

@Component( {
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class LoginComponent implements OnInit {
  user: User = new User();
  errorMessage: string;
  constructor(private authService: AuthService, private router: Router) { }



  ngOnInit() {
  }
  login() {
    this.authService.authenticate(this.user, (e) => {
      this.router.navigateByUrl('/app');
      console.log(e);
      let resp: any;
      resp = e;
      // this.user.fullName = 'ndh';
      if (resp) {
        //resp = parseJwt(resp.token);
        this.user.id = resp.userId;
        this.user.username = resp.userName;
        this.user.fullName = resp.fullName;
        let payLoad = this.parseJwt(resp.token);
        AppComponent.ROLES = payLoad['scopes'].split(",");
        AppComponent.USER = this.user;
        // store user details  in local storage to keep user logged in between page refreshes
        localStorage.setItem('currentUser', JSON.stringify(this.user));
        localStorage.setItem('token', resp.token);
        localStorage.setItem('roles', payLoad['scopes'].split(","));
      }
    });
  }
  
   parseJwt(token:any) {
    try {
      console.log(token);
      return JSON.parse(atob(token.split('.')[1]));
    } catch (e) {
      return null;
    }
  }

}