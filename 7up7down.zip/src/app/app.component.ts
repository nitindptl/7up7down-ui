import { Component } from '@angular/core';
import { User } from './model/model.user';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  static API_URL = 'https://ni3-cards.herokuapp.com';
 // static API_URL = 'http://localhost:8090';
  title = 'Cards Game';
  static ROLES :any= localStorage.getItem('roles');
  static USER: User = JSON.parse(localStorage.getItem('currentUser'));

  static isAdmin() {
    return this.ROLES.indexOf("ROLES_ADMIN");
  }
}
