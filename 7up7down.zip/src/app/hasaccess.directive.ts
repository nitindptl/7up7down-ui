import { Directive, OnInit, ElementRef, TemplateRef, ViewContainerRef, Input } from '@angular/core';
import { AppComponent } from './app.component';

@Directive({
  selector: '[hasPermission]'
})
export class HasaccessDirective implements OnInit {
  private currentUser;
  private permissions = [];

  constructor(
    private element: ElementRef,
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef
  ) {
  }

  ngOnInit() {
  }

  @Input()
  set hasPermission(val) {
    this.permissions = val;
    this.updateView();
  }

  private updateView() {
    if (this.checkPermission()) {
        this.viewContainer.createEmbeddedView(this.templateRef);
    } else {
      this.viewContainer.clear();
    }
  }

  private checkPermission() {
    let hasPermission = false;

    if (AppComponent.ROLES.indexOf("ROLE_ADMIN") !== -1) {
      hasPermission = true;
    } else if (AppComponent.ROLES.indexOf("ROLE_SUPER_ADMIN") !== -1) {
      hasPermission = true;
    }

    return hasPermission;
  }

}
