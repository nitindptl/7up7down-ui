import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {User} from '../model/model.user';
import {Http} from '@angular/http';
import {AppComponent} from '../app.component';

@Injectable()
export class ContestService {
  constructor(public http: HttpClient) { }

  createContest(contest :any) {
    return this.http.post(AppComponent.API_URL + '/contest',contest);
  }
  markContestComplete() {
    return this.http.get(AppComponent.API_URL + '/contest/complete');
  }
  getContest(contestId :number) {
    return this.http.get(AppComponent.API_URL + '/contest/'+ contestId);
  }
  getUserChallenges(contestId :number) {
    return this.http.get(AppComponent.API_URL + '/contest/'+ contestId+'/user/challenge');
  }
  getActiveContest() {
    return this.http.get(AppComponent.API_URL + '/contest/active');
  }
  getAllContest() {
    return this.http.get(AppComponent.API_URL + '/contest');
  }
  participateInContest(challenge: any) {
    return this.http.post(AppComponent.API_URL + '/contest/book',challenge);
  }
  getContestResult(contestId: number) {
    return this.http.get<any>(AppComponent.API_URL + '/contest/' + contestId + '/result');
  }
  getAllRules() {
    return this.http.get<any>(AppComponent.API_URL + '/contest/rules');
  }
}
