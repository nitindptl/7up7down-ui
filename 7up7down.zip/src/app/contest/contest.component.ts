import { Component, OnInit } from '@angular/core';
import { ContestService } from './contest.service';

@Component({
  selector: 'app-contest',
  templateUrl: './contest.component.html',
  styleUrls: ['./contest.component.css']
})
export class ContestComponent implements OnInit {

  constructor(private contestService:ContestService) { }
  contest: any = {};
  createNew = true;
  contestList: any = [];
  activeContest: any;
  ngOnInit() {
   // this.user = JSON.parse(localStorage.getItem('currentUser'));
   // this.getResult();
    this.getActiveContest();
  }

  isList(isList) {
    this.createNew = isList;
    
    if(!isList && this.contestList.length ==0)
      this.getContestList();
  }
  getResult() {
    this.contestService.getContestResult(this.activeContest.id).subscribe(response =>{
      this.contest = response;
    }); 
  }

  getActiveContest() {
    this.contestService.getActiveContest().subscribe(response =>{
      this.activeContest = response;
    }); 
  }
  
  getContestById() {
    this.contestService.getContest(this.contest.id).subscribe(response =>{
      this.contest = response;
    }); 
  }

  getContestList() {
    this.contestService.getAllContest().subscribe(response =>{
      this.contestList = response;
    }); 
  }

  createContest() {
    this.contestService.createContest(this.contest).subscribe(response =>{
      this.contest = {};
    }); 
  }

  markContestComplete() {
    this.contestService.markContestComplete().subscribe(response =>{
      this.contest = {};
    }); 
  }
}
