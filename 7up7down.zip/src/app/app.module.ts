import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { FormsModule } from '@angular/forms';
import { AuthService } from './services/auth.service';
import {HttpModule} from '@angular/http';
import {routing} from './app.routing';
import {UrlPermission} from './urlPermission/url.permissions';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { HomeComponent } from './components/layout/home.component';
import { MenuComponent } from './components/layout/menu/menu.component';
import { ContestComponent } from './contest/contest.component';
import { UserComponent } from './user/user.component';
import { AccountComponent } from './account/account.component';
import { AccountService } from './account/account.service';
import { ContestService } from './contest/contest.service';
import { HttpRequestInterceptor } from './services/http.interceptor';
import { ChallengeComponent } from './challenge/challenge.component';
import { HasaccessDirective } from './hasaccess.directive';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    MenuComponent,
    RegisterComponent,
    NotFoundComponent,
    ContestComponent,
    UserComponent,
    AccountComponent,
    ChallengeComponent,
    HasaccessDirective
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    routing,
    HttpClientModule
  ],
  providers: [
    AuthService,
    AccountService,
    ContestService,
    UrlPermission,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpRequestInterceptor,
      multi: true
  }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
